(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_blog_[id]_page_tsx_fbfdcf._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_blog_[id]_page_tsx_fbfdcf._.js",
  "chunks": [
    "static/chunks/node_modules_921084._.js",
    "static/chunks/_ee17b5._.js"
  ],
  "source": "dynamic"
});
