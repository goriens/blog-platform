(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_auth_login_page_tsx_1dfcca._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_auth_login_page_tsx_1dfcca._.js",
  "chunks": [
    "static/chunks/node_modules_zod_lib_index_mjs_ee760a._.js",
    "static/chunks/node_modules_react-icons_ri_index_mjs_0e2ec0._.js",
    "static/chunks/node_modules_c4af21._.js",
    "static/chunks/_5479b1._.js"
  ],
  "source": "dynamic"
});
