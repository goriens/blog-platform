(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/[root of the server]__9d1267._.css",
    "static/chunks/node_modules_next_f6bf7a._.js",
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_bi_index_mjs_cba0e8._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_1e445c._.js",
    "static/chunks/_0f73a6._.js"
  ],
  "source": "dynamic"
});
