(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_1dfcca._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_1dfcca._.js",
  "chunks": [
    "static/chunks/_6735e5._.js"
  ],
  "source": "dynamic"
});
