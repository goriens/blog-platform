(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_fbfdcf._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_fbfdcf._.js",
  "chunks": [
    "static/chunks/_00bc1b._.js"
  ],
  "source": "dynamic"
});
