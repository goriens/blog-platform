(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_blog_[id]_page_tsx_7a8edb._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_blog_[id]_page_tsx_7a8edb._.js",
  "chunks": [
    "static/chunks/node_modules_921084._.js",
    "static/chunks/_dfb0c5._.js"
  ],
  "source": "dynamic"
});
