"use client";

import { useState, useEffect } from "react";
import axios from "axios";
import { useRouter, useParams } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

const BASE_URL = "http://localhost:5000/api/v1/blog"; // Change if needed

export default function EditBlog() {
  const router = useRouter();
  const params = useParams();
  const [blogId, setBlogId] = useState<string | null>(null);

  const [blog, setBlog] = useState({
    title: "",
    content: "",
    tags: "",
    feature_image: "",
  });

  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    if (params?.id) {
      setBlogId(params.id as string);
    }
  }, [params]);

  useEffect(() => {
    if (!blogId) return;

    const fetchBlog = async () => {
      try {
        const { data } = await axios.get(`${BASE_URL}/${blogId}`);
        setBlog({
          title: data.blog?.title || "",
          content: data.blog?.content || "",
          tags: data.blog?.tags || "",
          feature_image: data.blog?.feature_image || "",
        });
      } catch (error) {
        console.error("Error fetching blog:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchBlog();
  }, [blogId]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setBlog({ ...blog, [e.target.name]: e.target.value });
  };

  const handleUpdate = async () => {
    setUpdating(true);
    try {
      await axios.patch(`${BASE_URL}/${blogId}`, blog);
      alert("✅ Blog updated successfully!");
      router.push("/"); // Redirect after update
    } catch (error) {
      console.error("Error updating blog:", error);
      alert("❌ Failed to update blog!");
    } finally {
      setUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="animate-spin w-8 h-8 text-gray-500" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto mt-10">
      <Card>
        <CardHeader>
          <CardTitle>Edit Blog</CardTitle>
        </CardHeader>
        <CardContent>
          <Input
            name="title"
            value={blog.title}
            onChange={handleChange}
            placeholder="Enter title"
            className="mb-4"
          />
          <Textarea
            name="content"
            value={blog.content}
            onChange={handleChange}
            placeholder="Enter content"
            className="mb-4"
          />
          <Input
            name="tags"
            value={blog.tags}
            onChange={handleChange}
            placeholder="Enter tags (comma-separated)"
            className="mb-4"
          />
          <Input
            name="feature_image"
            value={blog.feature_image}
            onChange={handleChange}
            placeholder="Enter image URL"
            className="mb-4"
          />
          <Button onClick={handleUpdate} disabled={updating} className="w-full">
            {updating ? (
              <Loader2 className="animate-spin w-5 h-5" />
            ) : (
              "Update Blog"
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
