"use client";

import axios from "axios";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation"; // ✅ Redirect ke liye
import { Button } from "../ui/button";
import Link from "next/link";
import { BiLogIn } from "react-icons/bi";
import Logo from "./Logo";
import { FaUserPlus } from "react-icons/fa";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const fetchProfile = async (setProfile: any, setError: any) => {
  try {
    const response = await axios.get(
      "http://localhost:5000/api/v1/user/profile",
      {
        withCredentials: true,
      }
    );
    setProfile(response.data);
  } catch (err: any) {
    if (err.response?.status === 401) {
      setProfile(null);
    } else {
      setError("Error fetching profile. Please try again.");
    }
  }
};

export default function Nav() {
  const [profile, setProfile] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    if (!profile) {
      fetchProfile(setProfile, setError);
    }
  }, [profile]);
  const handleLogout = async () => {
    try {
      await axios.get("http://localhost:5000/api/v1/auth/logout", {
        withCredentials: true,
      });
      setProfile(null);
      router.push("/auth/login");
    } catch (err: any) {
      console.error("Logout failed:", err.response?.data || err.message);
    }
  };

  return (
    <header className="h-16 mb-5 bg-primary flex justify-between items-center px-3">
      <Link href="/" aria-label="Blog Platform">
        <Logo />
      </Link>
      <li className="flex gap-2">
        {!profile ? (
          <>
            <Button variant="secondary" asChild className="flex gap-1">
              <Link href="/auth/register">
                <FaUserPlus size={17} />
                <span>Register</span>
              </Link>
            </Button>
            <Button
              variant="ghost"
              asChild
              className="flex gap-1 text-white border"
            >
              <Link href="/auth/login">
                <BiLogIn size={18} />
                <span>Login</span>
              </Link>
            </Button>
          </>
        ) : (
          <>
            <Button className="mt-1" variant="outline">
              <Link href="/create">Create Blog +</Link>
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger>
                <Avatar>
                  <AvatarImage src="" alt="@shadcn" />
                  <AvatarFallback>{profile.name?.charAt(0)}</AvatarFallback>
                </Avatar>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={handleLogout}>
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </>
        )}
      </li>
    </header>
  );
}
