export default function Logo() {
  return (
    <div>
      <h1 className="text-white font-bold text-xl bg-gradient-to-r from-blue-300 via-green-300 to-indigo-200 inline-block text-transparent bg-clip-text">
        BLOG APP
      </h1>
    </div>
  );
}
