import EditBlog from "@/components/EditBlog";

export default function EditBlogPage() {
  return <EditBlog />;
}
