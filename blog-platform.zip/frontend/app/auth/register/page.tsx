import RegisterForm from "@/components/auth/RegisterFrom";

export default function Register() {
  return (
    <div className="px-4 md:px-12 max-w-3xl m-auto">
      <RegisterForm />
    </div>
  );
}
