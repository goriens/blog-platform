"use client";

import axios from "axios";
import { useState, useEffect } from "react";

const fetchProfile = async (): Promise<any> => {
  try {
    const response = await axios.get(
      "http://localhost:5000/api/v1/user/profile",
      {
        withCredentials: true,
      }
    );

    return response.data; // Return profile data
  } catch (err: any) {
    console.error("Error fetching profile:", err.response?.data || err.message);
    return null;
  }
};

// React component
const ProfilePage = () => {
  const [profile, setProfile] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const getProfile = async () => {
      const profileData = await fetchProfile();
      if (profileData) {
        setProfile(profileData);
      } else {
        setError("Failed to fetch profile. Please log in again.");
      }
    };

    getProfile();
  }, []);

  if (error) return <div>{error}</div>;
  if (!profile) return <div>Loading...</div>;

  return (
    <div>
      <h1>Welcome, {profile.name}</h1>
      <p>Email: {profile.email}</p>
    </div>
  );
};

export default ProfilePage;
