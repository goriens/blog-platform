"use client";

import { useEffect, useState } from "react";
import axios from "axios";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

export default function Home() {
  const [blogs, setBlogs] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/v1/blog");
        setBlogs(response.data.blogs);
        setLoading(false);
      } catch (err: any) {
        setError("Failed to fetch blogs.");
        setLoading(false);
      }
    };

    fetchBlogs();
  }, []);

  return (
    <div className="max-w-[1200px] container py-6 px-5">
      <h1 className="text-3xl font-semibold mb-4">Blog Posts</h1>
      {loading && (
        <div className="flex justify-center">
          <Loader2 className="animate-spin text-blue-500" size={32} />
        </div>
      )}

      {error && <div className="text-red-500">{error}</div>}

      {!loading && blogs.length === 0 && <div>No blogs found!</div>}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {blogs.map((blog: any) => (
          <Card key={blog._id} className="shadow-md">
            <CardHeader>
              <CardTitle className="text-lg font-medium">
                {blog.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700">{blog.content.slice(0, 100)}...</p>
            </CardContent>
            <Button variant="link" asChild>
              <a href={`/blog/${blog._id}`} className="text-blue-500">
                Read more
              </a>
            </Button>
          </Card>
        ))}
      </div>
    </div>
  );
}
