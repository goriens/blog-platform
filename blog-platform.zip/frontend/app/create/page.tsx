"use client";

import { useState } from "react";
import axios from "axios";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

const BASE_URL = "http://localhost:5000/api/v1/blog";

export default function CreateBlog() {
  const router = useRouter();
  const [blog, setBlog] = useState({
    title: "",
    content: "",
    tags: "",
    feature_image: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setBlog({ ...blog, [e.target.name]: e.target.value });
  };

  const handleCreate = async () => {
    try {
      const { data } = await axios.post(BASE_URL, blog, {
        withCredentials: true,
      });
      alert("Blog created successfully!");
      router.push(`/`);
    } catch (error) {
      console.error("Error creating blog:", error);
      alert("Failed to create blog!");
    }
  };

  return (
    <div className="max-w-xl mx-auto p-4 bg-white shadow-md rounded-lg">
      <h2 className="text-xl font-bold mb-4">Create New Blog</h2>
      <Input
        name="title"
        value={blog.title}
        onChange={handleChange}
        placeholder="Enter title"
        className="mb-3"
      />
      <Textarea
        name="content"
        value={blog.content}
        onChange={handleChange}
        placeholder="Enter content"
        className="mb-3"
      />
      <Input
        name="tags"
        value={blog.tags}
        onChange={handleChange}
        placeholder="Enter tags (comma-separated)"
        className="mb-3"
      />
      <Input
        name="feature_image"
        value={blog.feature_image}
        onChange={handleChange}
        placeholder="Enter image URL"
        className="mb-3"
      />
      <Button onClick={handleCreate} className="w-full">
        Create Blog
      </Button>
    </div>
  );
}
