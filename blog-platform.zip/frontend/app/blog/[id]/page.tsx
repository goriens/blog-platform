"use client";

import { useEffect, useState } from "react";
import axios from "axios";
import { useParams, useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

const BASE_URL = "http://localhost:5000/api/v1";

export default function BlogPost() {
  const { id: blogId } = useParams();
  const [blog, setBlog] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [comments, setComments] = useState<{ title: string }[]>([]);
  const [commentText, setCommentText] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const router = useRouter();

  useEffect(() => {
    if (!blogId) return;

    const fetchBlog = async () => {
      try {
        const { data } = await axios.get(`${BASE_URL}/blog/${blogId}`);
        setBlog(data.blog);
      } catch (err: any) {
        setError("Failed to fetch blog.");
      } finally {
        setLoading(false);
      }
    };

    const fetchComments = async () => {
      try {
        const { data } = await axios.get(`${BASE_URL}/comments/${blogId}`, {
          withCredentials: true,
        });
        setComments(data.comments);
      } catch (err) {
        console.error("Error fetching comments:", err);
      }
    };

    fetchBlog();
    fetchComments();
  }, [blogId]);

  const handleAddComment = async () => {
    if (!commentText.trim()) return;

    setSubmitting(true);
    try {
      const newComment = { title: commentText, blog: blogId };
      await axios.post(`${BASE_URL}/comments`, newComment, {
        withCredentials: true,
      });

      setComments([...comments, newComment]);
      setCommentText(""); // Clear input
    } catch (err) {
      console.error("Error submitting comment:", err);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-10">
        <Loader2 className="animate-spin text-blue-500" size={40} />
      </div>
    );
  }

  if (error) {
    return <div className="text-red-500 text-center py-5">{error}</div>;
  }

  return (
    <div className="container max-w-3xl py-10 m-auto">
      <Card>
        <CardHeader>
          <CardTitle className="text-3xl font-semibold">
            {blog?.title}
            <div className="mt-4 text-sm text-gray-500 flex justify-between items-center">
              <span className="font-semibold">Tags: {blog?.tags}</span>
              <Button
                className="mt-4"
                onClick={() => router.push(`/edit/${blogId}`)}
              >
                Edit Blog
              </Button>
            </div>
          </CardTitle>
        </CardHeader>

        <CardContent>
          {blog?.feature_image && (
            <div className="mb-4">
              <Image
                src={blog.feature_image}
                alt={blog.title}
                width={600}
                height={300}
                className="rounded-lg shadow-lg"
              />
            </div>
          )}
          <p className="text-lg text-gray-600">{blog?.content}</p>
          <div className="mt-2 text-sm text-gray-500">
            <span className="font-semibold cursor-pointer">Likes:</span>{" "}
            {blog?.likes}
          </div>
        </CardContent>
      </Card>

      <div className="mt-8">
        <h3 className="text-xl font-bold mb-3">Comments</h3>

        {comments.length === 0 ? (
          <p className="text-gray-500">No comments yet.</p>
        ) : (
          <div className="space-y-2">
            {comments.map((c, index) => (
              <div
                key={index}
                className="p-2 border rounded-md text-gray-800 flex justify-between"
              >
                <span className="text-sm">{c.title}</span>
                <span className="text-sm">user:{c?.user?.name}</span>
              </div>
            ))}
          </div>
        )}

        <div className="mt-4">
          <Textarea
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            placeholder="Write your comment..."
            className="mb-3"
          />
          <Button
            onClick={handleAddComment}
            disabled={submitting}
            className="w-full"
          >
            {submitting ? "Adding Comment..." : "Add Comment"}
          </Button>
        </div>
      </div>
    </div>
  );
}
